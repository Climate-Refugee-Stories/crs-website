---
title: Home
banner:
  title: "Climate Refugee Stories<br><span class='hero-subtitle'>A public history project<br>narrating the fight for climate justice.</span>"
  background_img: i-ptQrJ35
  logo: i-Dfx3zd6
about:
  content: |
    Climate Refugee Stories is about people, migration, and borders. This project serves as a multimedia archive, and education project <br>that uplifts the stories of people around the world who have been displaced by direct or indirect impacts of climate change, <br>and documents the ways communities are resilient in the face of overlapping crises--including the COVID-19 pandemic.
    Cover Artwork by [Bo Thai](about/bo-daraphant/)
  button:
    enable : true
    label : "learn more"
    URL : "about"
stories:
  title : "Stories"
  description: "Our Stories Project documents the lived experiences of communities impacted by climate change, highlighting personal narratives, environmental justice campaigns, and local solutions."
archive:
  title : "Archive"
  item_show : 5
resources:
  title : "Resources"
  button:
    enable : true
    label : "learn more"
    URL : "resources"
  item:
    - title : "K-12 Curriculum"
      icon : "ti-ruler-pencil"
      content : "Gain a greater understanding of climate-induced migration, and how it fits within the broader phenomenon of human migration."
      highlighted : false
      URL: resources/#k-12-curriculum

    - title : "Ways to Take Action"
      icon : "ti-clipboard"
      content : "Check out our Community Discussion Toolkit, Media Toolkit, Organizations, and more!"
      highlighted : true
      URL: resources/#take-action

    - title : "Climate Migration Syllabus"
      icon : "ti-bookmark-alt"
      content : "A crowd-sourced, expanding set of resources for further reading, research, and action."
      highlighted : false
      URL: resources/#climate-migration-syllabus
---
